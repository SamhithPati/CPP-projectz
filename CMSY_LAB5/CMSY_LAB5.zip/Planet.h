// Specification file for the food class
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

#ifndef PLANET_H
#define PLANET_H

class Planet
{
private:
	string planetName;
	int planetID;
	int planetMoons;

	// Mutator Prototypes
	void setPlanetID();
	void setPlanetMoons();
	void setPlanetName();

public:
	// Constructors 
	Planet();
	Planet(const string);
	
	// Accessors
	string getPlanetName() const;
	int getPlanetID() const;
	int getPlanetMoons() const;

	// Overloaded operators
	Planet& operator++(); // Prefix ++
	Planet operator++(int); // Postfix ++ 
	Planet& operator=(const Planet& other); // Assignment
	Planet operator-(); // Unary minus
	Planet operator+(); // Unary plus
	friend ostream& operator<<(ostream& os, const Planet& planet);
	friend istream& operator>>(istream& is, Planet& planet);
};

#endif