// Samhith Patibandla
// 03/13/2024
// This program manages information about planets.

#include <iostream>
#include <iomanip>
#include "Planet.h" // Assuming Planet class is defined in "Planet.h"
#include <string>
using namespace std;

// Prototypes
void projIntro();

int main()
{
	projIntro(); // Display project introduction

	// Create planets
	Planet Planet1("Jupiter");
	Planet Planet2, Planet3, Planet4, Planet5, Planet6;

	// Display planet information using standard streaming operator
	cout << "\nUsing cout and the standard streaming operator: " << endl;
	cout << "The planet name is: " << Planet1.getPlanetName() << endl;
	cout << "The planet number is: " << Planet1.getPlanetID() << endl;
	cout << "The planet has " << Planet1.getPlanetMoons() << " moons." << endl;

	// Display planet information using overloaded streaming operator
	cout << "\nUsing cout and the overloaded streaming operator: " << endl;
	cout << Planet1 << endl;

	// Using prefix operator to increment planet numbers
	cout << "\nUsing the prefix operator for planet 1 and planet 2: " << endl;
	Planet2 = ++Planet1;
	cout << Planet1 << endl;
	cout << Planet2 << endl;

	// Using prefix operator for planet 1 and planet 3
	cout << "\nUsing the prefix operator for planet 1 and planet 3: " << endl;
	Planet3 = Planet1++;
	cout << Planet1 << endl;
	cout << Planet3 << endl;

	// Using overloaded streaming operator to input planet information
	cout << "\nUsing the overloaded streaming operator for planet 4: " << endl;
	cin >> Planet4;
	cout << Planet4 << endl;

	// Using overloaded '-' operator to create a new planet with values associated with the first planet
	cout << "\nUsing the overloaded '-' operator for planet 5: " << endl;
	Planet5 = -Planet1;
	cout << Planet5 << endl;

	// Using overloaded '+' operator to create a new planet with values associated with the last planet
	cout << "\nUsing the overloaded '+' operator for planet 6: " << endl;
	Planet6 = +Planet1;
	cout << Planet6 << endl;

	cout << "\n\nThank you for using the program!\n\n";

	system("pause"); // Pause the program before exiting
	return 0;
}

// Function to display project introduction
void projIntro() {
	cout << "\t\t\t\tCMSY 171 Lab 5\n";
	cout << "Copyright 2022 - Howard Community College All rights reserved; Unauthorized duplication prohibited.\n";
	cout << "\n\t\tWelcome to CMSY-171 Planet Operations Program\n";
}